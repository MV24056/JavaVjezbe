
public abstract class Vozilo {

	private int id ;
	protected double maxBrzina;
	protected double brKm;
	
	
	public Vozilo(int id, double maxBrzina, double brKm) {
		super();
		this.setId (id);
		this.setMaxBrzina (maxBrzina);
		this.setBrKm (brKm);
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getMaxBrzina() {
		return maxBrzina;
	}
	public void setMaxBrzina(double maxBrzina) {
		this.maxBrzina = maxBrzina;
	}
	
	public double getBrKm() {
		return brKm;
	}
	public void setBrKm(double brKm) {
		this.brKm = brKm;
	}
	
	
	void info (){
		System.out.println("{ 'Vozilo': , 'IDVozila':" + getId()+ "','maxBrzina':" + getMaxBrzina()+ ")");
	}
	
	
	
	
	public abstract double izracunajVrijemeDostave (double udaljenostKm); {
		
	}
	
	
	
	
}
