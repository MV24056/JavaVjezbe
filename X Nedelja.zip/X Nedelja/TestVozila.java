import java.util.ArrayList;

public class TestVozila {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		ArrayList<Vozilo> x = new ArrayList<>();
		
		x.add (new Bicikl (20,10,50));
		x.add (new Motor (1,60,30));
		x.add (new Automobil (3,10,100));
		
		double brKm=10;
		
		for (Vozilo v : x) {
			System.out.print("  Vrijeme udaljennosti:  " +   v.izracunajVrijemeDostave(brKm) );
		}
	}

}
