
public class Motor extends Vozilo implements Ekonomican {

	
	
	public Motor(int id, double maxBrzina, double brKm) {
		super(id, maxBrzina, brKm);
	}
	
	

	@Override
	public double potrosnjaPoKm() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double izracunajVrijemeDostave(double udaljenostKm) {
		// TODO Auto-generated method stub
		return brKm / maxBrzina;
	}

	
}
