
public class Bicikl extends Vozilo implements Ekonomican {

	private double brKm;
	
	public Bicikl(int id, double maxBrzina, double brKm) {
		super(id, maxBrzina, brKm);
	}

	
	public double getBrKm() {
		return brKm;
	}

	public void setBrKm(double brKm) {
		this.brKm = brKm;
	}

	
	@Override
	public double potrosnjaPoKm() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double izracunajVrijemeDostave(double udaljenostKm) {
		// TODO Auto-generated method stub
		return brKm / maxBrzina;
	}

	
	
}
