
public interface Ekonomican {

	public double potrosnjaPoKm();
}
