package projekat4;

interface Collidable {
	boolean intersects(Collidable other);
}
